extends Node2D

var is_inside_area := false  # Tracks if player is still in the area

func _ready() -> void:

	$npc5_area.connect('body_entered', Callable(self, 'play_animation'))
	$npc5_area.connect('body_exited', Callable(self, 'hide_animation'))

func play_animation(body):
	is_inside_area = true

	$ShLabel.show()
	$AnimationPlayer.play('shrimp_greet')
	await $AnimationPlayer.animation_finished
	if not is_inside_area: return

	$ShLabel.hide()
	$ShLabel2.show()
	$AnimationPlayer.play('shrimp_guess')
	await $AnimationPlayer.animation_finished
	if not is_inside_area: return
	
	$ShLabel2.hide()
	$ShLabel3.show()
	$AnimationPlayer.play('shrimp_cough')
	await $AnimationPlayer.animation_finished
	if not is_inside_area: return


func hide_animation(body):
	is_inside_area = false
	$ShLabel.hide()
	$ShLabel2.hide()
	$ShLabel3.hide()
	$AnimationPlayer.stop()
	
