extends Node2D

var is_inside_area := false  # Tracks if player is still in the area

func _ready() -> void:
	$npc6_area.connect('body_entered', Callable(self, 'play_animation'))
	$npc6_area.connect('body_exited', Callable(self, 'hide_animation'))

func play_animation(body):
	is_inside_area = true

	$QLabel.show()
	$AnimationPlayer.play('quill_scare')
	await $AnimationPlayer.animation_finished
	if not is_inside_area: return

	$QLabel.hide()
	$QLabel2.show()
	$AnimationPlayer.play('quill_explain')
	await $AnimationPlayer.animation_finished
	if not is_inside_area: return
	
	$QLabel2.hide()
	$QLabel3.show()
	$AnimationPlayer.play('quill concern')
	await $AnimationPlayer.animation_finished
	if not is_inside_area: return


func hide_animation(body):
	is_inside_area = false
	$QLabel.hide()
	$QLabel2.hide()
	$QLabel3.hide()
	$AnimationPlayer.stop()
	
