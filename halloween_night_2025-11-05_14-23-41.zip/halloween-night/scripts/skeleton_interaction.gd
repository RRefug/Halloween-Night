extends Node2D

var is_inside_area := false  # Tracks if player is still in the area

func _ready() -> void:
	print('Skeleton ready')
	$npc2_area.connect('body_entered', Callable(self, 'play_animation'))
	$npc2_area.connect('body_exited', Callable(self, 'hide_animation'))

func play_animation(body):
	is_inside_area = true
	print('WE DID IT')

	$SLabel.show()
	$AnimationPlayer.play('skeleton_concern')
	await $AnimationPlayer.animation_finished
	if not is_inside_area: return

	$SLabel.hide()
	$SLabel2.show()
	$AnimationPlayer.play('skeleton_shock')
	await $AnimationPlayer.animation_finished
	if not is_inside_area: return


func hide_animation(body):
	is_inside_area = false
	$SLabel.hide()
	$SLabel2.hide()
	$AnimationPlayer.stop()
	
