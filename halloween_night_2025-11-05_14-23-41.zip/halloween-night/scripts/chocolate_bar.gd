extends Area2D

@onready var game_manager = %GameManager

# Signal for when we interact with the candy
func _on_body_entered(body: Node2D) -> void:

	game_manager.add_point()
	# removes bar from scene
	queue_free()
	
