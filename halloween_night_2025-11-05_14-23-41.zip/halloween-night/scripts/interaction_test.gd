extends Node2D

var is_inside_area := false  # Tracks if player is still in the area

func _ready() -> void:
	$npc_area.connect('body_entered', Callable(self, 'play_animation'))
	$npc_area.connect('body_exited', Callable(self, 'hide_animation'))

func play_animation(body):
	is_inside_area = true

	$Label.show()
	$AnimationPlayer.play('Text_dialogue')
	await $AnimationPlayer.animation_finished
	if not is_inside_area: return

	$Label.hide()
	$Label2.show()
	$AnimationPlayer.play('pause')
	await $AnimationPlayer.animation_finished
	if not is_inside_area: return

	$Label2.hide()
	$Label3.show()
	$AnimationPlayer.play('question')
	await $AnimationPlayer.animation_finished
	if not is_inside_area: return

func hide_animation(body):
	is_inside_area = false
	$Label.hide()
	$Label2.hide()
	$Label3.hide()
	$AnimationPlayer.stop()
	
