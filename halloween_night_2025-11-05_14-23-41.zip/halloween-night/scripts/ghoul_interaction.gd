extends Node2D

var is_inside_area := false  # Tracks if player is still in the area

func _ready() -> void:
	$npc4_area.connect('body_entered', Callable(self, 'play_animation'))
	$npc4_area.connect('body_exited', Callable(self, 'hide_animation'))

func play_animation(body):
	is_inside_area = true

	$GhLabel.show()
	$AnimationPlayer.play('witch_memory')
	await $AnimationPlayer.animation_finished
	if not is_inside_area: return

	$GhLabel.hide()
	$GhLabel2.show()
	$AnimationPlayer.play('witch_core_memory')
	await $AnimationPlayer.animation_finished
	if not is_inside_area: return

	$GhLabel2.hide()

func hide_animation(body):
	is_inside_area = false
	$GhLabel.hide()
	$GhLabel2.hide()
	$AnimationPlayer.stop()
	
