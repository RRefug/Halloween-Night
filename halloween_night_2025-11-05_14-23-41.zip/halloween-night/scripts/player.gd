extends CharacterBody2D

# Math plane y axis is inverted. Negative going up, positive going down.
# x axis is still the same. 

const SPEED = 150.0
const JUMP_VELOCITY = -400.0
@onready var animated_sprite = $AnimatedSprite2D

func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Handle jump.
	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var x_direction := Input.get_axis("move_left", "move_right")
	var y_direction := Input.get_axis("move_up", "move_down")
	
	#print('X-direction: ', x_direction)
	#print('Y-direction: ', y_direction)
	
	# Play animations
	if x_direction == 0.0 and y_direction == 0.0:
		#print('X-direction: ', x_direction)
		#print('Y-direction: ', y_direction)
		animated_sprite.play("idle")
	
	elif x_direction == 1.0 and y_direction == 0.0:
		#print('X-direction: ', x_direction)
		#print('Y-direction: ', y_direction)
		animated_sprite.play("walking_right")
		
	elif x_direction == -1.0 and y_direction == 0.0:
		#print('Y-direction: ', y_direction)
		#print('X-direction: ', x_direction)
		animated_sprite.play("walking_left")
	
	elif x_direction == 0.0 and y_direction == -1.0:
		#print('Y-direction: ', y_direction)
		#print('X-direction: ', x_direction)wa
		animated_sprite.play("walking_up")
		
	elif x_direction == 0.0 and y_direction == 1.0:
		animated_sprite.play('walkiing_down')
	
	
	# Apply movement
	if x_direction:
		velocity.x = x_direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
		
	if y_direction:
		velocity.y = y_direction * SPEED
	else:
		velocity.y = move_toward(velocity.y, 0, SPEED)
	
	
	#self.move_local_y(y_direction)
	#self.move_local_x(x_direction)
	
	move_and_slide()
	#move_and_collide(velocity.round())
	
