extends Node2D

var is_inside_area := false  # Tracks if player is still in the area

func _ready() -> void:
	$npc3_area.connect('body_entered', Callable(self, 'play_animation'))
	$npc3_area.connect('body_exited', Callable(self, 'hide_animation'))

func play_animation(body):
	is_inside_area = true

	$GLabel.show()
	$AnimationPlayer.play('ghost_question')
	await $AnimationPlayer.animation_finished
	if not is_inside_area: return


func hide_animation(body):
	is_inside_area = false
	$GLabel.hide()
	$AnimationPlayer.stop()
	
