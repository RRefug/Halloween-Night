extends Area2D

func _ready() -> void:
	print('created')
	hide()

func _on_body_entered(body: Node2D) -> void:
	print('Hey!')
	show()
	

func _on_body_exited(body: Node2D) -> void:
	hide()


func _on_input_event(viewport: Node, event: InputEvent, shape_idx: int) -> void:
	if event:
		print('YES ', event)
	
