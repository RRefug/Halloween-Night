extends Node



@onready var starting_message = $StartingMessage
@onready var ending_message = $EndingMessage
@onready var starting_cam = $"../Player/Camera2D"
@onready var ending_cam = $ending_cam

var candy_score = 0

func _on_ready() -> void:
	ending_message.hide()
	starting_cam.make_current()
	starting_message.text = 'Have Fun Trick or Treating!'
	

func add_point():
	candy_score += 1
	if candy_score == 1:
		starting_message.hide()
	
	if candy_score == 6:
		ending_message.text = 'HAPPY\nHALLOWEEN'
		ending_cam.make_current()
		ending_message.show()
